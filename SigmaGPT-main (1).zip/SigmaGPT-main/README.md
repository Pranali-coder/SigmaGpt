# SigmaGPT
A MERN based ChatGPT replica implemented from scratch using OpenAI.
